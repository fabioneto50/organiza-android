package com.organiza.app.model

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.util.UUID

enum class TaskCategory(val label: String) {
    CASA("Casa"), SAUDE("Saúde"), EXERCICIO("Exercício"), ESTUDO("Estudo"),
    TRABALHO("Trabalho"), RECADOS("Recados"), PESSOAL("Pessoal")
}

enum class TaskPriority(val label: String, val weight: Int) {
    BAIXA("Baixa", 1), MEDIA("Média", 2), ALTA("Alta", 3), URGENTE("Urgente", 4)
}

enum class EnergyDemand(val label: String, val value: Int) {
    BAIXA("Baixa", 1), MEDIA("Média", 2), ALTA("Alta", 3)
}

enum class PreferredMoment(val label: String) {
    QUALQUER("Qualquer"), MANHA("Manhã"), TARDE("Tarde"), NOITE("Noite")
}


enum class EnergyMode(val label: String, val energyValue: Int, val message: String) {
    ALTA("Energia alta", 5, "Hoje há margem para coisas mais exigentes."),
    NORMAL("Energia normal", 3, "Vamos manter um ritmo equilibrado."),
    BAIXA("Energia baixa", 2, "Hoje fazemos o essencial e protegemos margem."),
    RECUPERAR("Preciso de recuperar", 1, "Hoje a prioridade é recuperar. O resto pode esperar.")
}

enum class PlanningIntensity(val label: String, val description: String) {
    LEVE("Leve", "Menos tarefas, mais margem e descanso"),
    EQUILIBRADO("Equilibrado", "O essencial com espaço para a vida real"),
    PRODUTIVO("Produtivo", "Mais avanço, sem ultrapassar os limites de energia")
}

enum class RescueReason(val label: String) {
    ACORDEI_TARDE("Acordei tarde"),
    PERDI_TEMPO("Perdi tempo"),
    PLANO_ATRASADO("Não consegui cumprir o plano"),
    MUDOU_O_DIA("O meu dia mudou")
}

enum class ShiftType(val label: String) {
    DIA("Diurno"), TARDE("Tarde"), NOITE("Noturno"), LONGO("Prolongado"),
    FOLGA("Folga"), FERIAS("Férias"), OUTRO("Outro")
}

enum class ShiftSwapStatus(val label: String) {
    NENHUMA("Sem troca"), PENDENTE("Troca pendente"), CONFIRMADA("Troca confirmada")
}

data class ShiftTemplate(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val code: String,
    val type: ShiftType,
    val startTime: String,
    val endTime: String,
    val colorHex: String,
    val system: Boolean = false,
    val favorite: Boolean = false
) {
    fun start(): LocalTime = LocalTime.parse(startTime)
    fun end(): LocalTime = LocalTime.parse(endTime)
}

fun defaultShiftTemplates(): List<ShiftTemplate> = listOf(
    ShiftTemplate("builtin-morning", "Manhã", "M", ShiftType.DIA, "08:00", "16:00", "#4E7AA8", true, true),
    ShiftTemplate("builtin-afternoon", "Tarde", "T", ShiftType.TARDE, "16:00", "23:59", "#8E6BA8", true, true),
    ShiftTemplate("builtin-night", "Noite", "N", ShiftType.NOITE, "20:00", "08:00", "#3B244F", true, true),
    ShiftTemplate("builtin-long", "12 horas", "12H", ShiftType.LONGO, "08:00", "20:00", "#6B6B6B", true, false),
    ShiftTemplate("builtin-off", "Folga", "Folga", ShiftType.FOLGA, "00:00", "00:00", "#A9453A", true, true),
    ShiftTemplate("builtin-vacation", "Férias", "Férias", ShiftType.FERIAS, "00:00", "00:00", "#C9848F", true, false)
)

enum class AppointmentSource { MANUAL, DEVICE_CALENDAR }

data class LifeTask(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val durationMinutes: Int,
    val category: TaskCategory = TaskCategory.PESSOAL,
    val priority: TaskPriority = TaskPriority.MEDIA,
    val energyDemand: EnergyDemand = EnergyDemand.MEDIA,
    val preferredMoment: PreferredMoment = PreferredMoment.QUALQUER,
    val dueDate: String? = null,
    val completed: Boolean = false,
    val createdAt: String = LocalDateTime.now().toString()
) {
    fun dueLocalDate(): LocalDate? = dueDate?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
}

data class Shift(
    val id: String = UUID.randomUUID().toString(),
    val date: String,
    val type: ShiftType,
    val startTime: String,
    val endTime: String,
    val note: String = "",
    val templateId: String? = null,
    val swapWith: String = "",
    val swapStatus: ShiftSwapStatus = ShiftSwapStatus.NENHUMA
) {
    fun localDate(): LocalDate = LocalDate.parse(date)
    fun start(): LocalTime = LocalTime.parse(startTime)
    fun end(): LocalTime = LocalTime.parse(endTime)
}

data class DayNote(
    val id: String = UUID.randomUUID().toString(),
    val date: String,
    val text: String
)

data class Appointment(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val date: String,
    val startTime: String,
    val endTime: String,
    val location: String = "",
    val note: String = "",
    val source: AppointmentSource = AppointmentSource.MANUAL,
    val externalId: String? = null
) {
    fun localDate(): LocalDate = LocalDate.parse(date)
    fun start(): LocalTime = LocalTime.parse(startTime)
    fun end(): LocalTime = LocalTime.parse(endTime)
}

data class Goal(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val category: TaskCategory = TaskCategory.PESSOAL,
    val targetDate: String? = null,
    val progressPercent: Int = 0,
    val note: String = ""
)

data class Habit(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val durationMinutes: Int = 20,
    val energyDemand: EnergyDemand = EnergyDemand.BAIXA,
    val preferredMoment: PreferredMoment = PreferredMoment.QUALQUER,
    val daysOfWeek: Set<Int> = DayOfWeek.entries.map { it.value }.toSet(),
    val completedDates: Set<String> = emptySet(),
    val active: Boolean = true
) {
    fun isDue(date: LocalDate): Boolean = active && daysOfWeek.contains(date.dayOfWeek.value)
    fun isCompleted(date: LocalDate): Boolean = completedDates.contains(date.toString())
}

enum class PlanBlockType { TURNO, COMPROMISSO, TAREFA, HABITO, RECUPERACAO, PESSOAL, REFEICAO }

data class PlanBlock(
    val id: String = UUID.randomUUID().toString(),
    val date: String,
    val startTime: String,
    val endTime: String,
    val title: String,
    val subtitle: String = "",
    val type: PlanBlockType,
    val sourceTaskId: String? = null,
    val sourceHabitId: String? = null,
    val sourceAppointmentId: String? = null
)

data class HealthSnapshot(
    val lastSleepHours: Double? = null,
    val lastSleepEnd: String? = null,
    val lastSync: String? = null
)

data class UserPreferences(
    val currentEnergy: Int = 3,
    val protectSleepAfterNight: Boolean = true,
    val dayStartHour: Int = 8,
    val dayEndHour: Int = 22,
    val recoveryHoursAfterNight: Int = 7,
    val notificationsEnabled: Boolean = false,
    val reminderMinutes: Int = 20,
    val autoReplan: Boolean = true,
    val useSleepFromHealthConnect: Boolean = false,
    val userName: String = "",
    val avatar: String = "",
    val visualTheme: String = "STRIPES",
    val cardOpacity: Float = 0.72f,
    val autoAdvanceShifts: Boolean = true,
    val planningIntensity: PlanningIntensity = PlanningIntensity.EQUILIBRADO,
    val planningHorizonDays: Int = 7,
    val proactiveSuggestions: Boolean = true,
    val dailySaluQuoteDate: String = "",
    val dailySaluQuoteText: String = ""
)

data class AppData(
    val tasks: List<LifeTask> = emptyList(),
    val shifts: List<Shift> = emptyList(),
    val shiftTemplates: List<ShiftTemplate> = defaultShiftTemplates(),
    val dayNotes: List<DayNote> = emptyList(),
    val appointments: List<Appointment> = emptyList(),
    val goals: List<Goal> = emptyList(),
    val habits: List<Habit> = emptyList(),
    val plan: List<PlanBlock> = emptyList(),
    val preferences: UserPreferences = UserPreferences(),
    val health: HealthSnapshot = HealthSnapshot()
)

data class TimeSuggestion(
    val minutesAvailable: Int,
    val selectedTasks: List<LifeTask>,
    val totalMinutes: Int,
    val message: String
)

data class MonthShiftSummary(
    val shifts: Int,
    val nights: Int,
    val offDays: Int,
    val vacationDays: Int,
    val workedMinutes: Int,
    val countsByType: Map<String, Int> = emptyMap()
) {
    val workedHours: Double get() = workedMinutes / 60.0
}

data class ShiftWarning(
    val date: String,
    val message: String
)


data class DailyMission(
    val title: String,
    val reason: String,
    val message: String,
    val sourceTaskId: String? = null
)

data class FreeWindow(
    val date: String,
    val startTime: String,
    val endTime: String,
    val minutes: Int,
    val suggestion: String
)

data class BalanceSnapshot(
    val score: Int,
    val workMinutes: Int,
    val recoveryMinutes: Int,
    val flexibleMinutes: Int,
    val personalMinutes: Int,
    val message: String
)

data class DecisionResult(
    val choice: String,
    val reason: String,
    val alternative: String = ""
)

data class RescueResult(
    val plan: List<PlanBlock>,
    val message: String,
    val pendingItems: Int
)
