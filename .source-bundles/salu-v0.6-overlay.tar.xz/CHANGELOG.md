# Changelog

## v0.6.0

- Home ganha **A frase da SALU**, com uma mensagem curta diária, persistente durante todo o dia e escolhida com sensibilidade ao contexto.
- A frase surge imediatamente abaixo da data e usa a mascote de forma subtil.
- A navegação inferior passa a abrir cada separador sempre no início, sem restaurar a posição de scroll anterior.
- Mantida a identidade visual e todas as funcionalidades da v0.5.


## 0.5.0 — SALU como assistente de vida

- Nova área **SALU** na navegação principal.
- **Missão do Dia** baseada em energia, turnos, prazos e recuperação.
- **Modo Energia** rápido: alta, normal, baixa e recuperação.
- **SALU DECIDE** para comparar duas opções com base no contexto do dia.
- **SALU RESCUE** para recomeçar o planeamento quando a vida muda.
- **Encontra o meu tempo** deteta janelas livres sem transformar automaticamente todo o tempo livre em tarefas.
- **Índice de Equilíbrio** para trabalho, recuperação, tarefas e tempo pessoal.
- Planeamento em **7, 14 ou 30 dias**.
- Ritmos de planeamento **Leve, Equilibrado e Produtivo**.
- Sugestões proativas contextuais da SALU.
- “Tenho X minutos” passa a recomendar descanso quando o contexto pede recuperação.
- Mantém toda a identidade, turnos rápidos, widget, backup e exportação da v0.4.
- Sem som nesta versão.

## 0.4.0 — SALU FLOW

- Renome da aplicação para **SALU FLOW** e assinatura “Deixa comigo.”.
- Novo ícone com a mascote oficial: cão branco sobre fundo azul; versão transparente no interior da app.
- Splash screen e mascote integrada na Home, organização do dia, sugestões, estados vazios e feedback de conclusão.
- Fundo listado, tipografia cursiva nos títulos e cartões translúcidos com opacidade ajustável.
- Saudação personalizada com nome e avatar opcional.
- Barra inferior com Home, Agenda, Plano, Tarefas, Turnos e Mais.
- Calendário mensal de turnos com avanço automático para o dia seguinte.
- Escala rápida, modo apagar, favoritos, múltiplos turnos, aplicação do mesmo turno a vários dias e repetição de semanas.
- Sequências de escala aceitam também códigos de turnos personalizados (ex.: D2, N2, M2).
- Notas por dia, trocas de turno, resumo mensal, horas trabalhadas e avisos de descanso.
- Partilha da escala em imagem/PDF, backup/restauro e widget Hoje/Amanhã.
- Mensagens e notificações com a voz da mascote, sem áudio nesta versão.

## 0.4.0 — 2026-08-21

- Novo tema visual com fundo às riscas fornecido pelo utilizador, paleta creme/azul e vermelho-acastanhado e títulos de estilo manuscrito.
- Cartões translúcidos e opacidade ajustável.
- Saudação personalizada com nome e avatar/inicial opcional.
- Barra inferior com Home e Turnos dedicados; Home regressa sempre à página inicial.
- Escala rápida: selecionar um tipo e preencher dias consecutivos.
- Avanço automático para o dia seguinte após aplicar um turno.
- Turnos favoritos e legenda de cores.
- Resumo mensal com turnos, noites, folgas, férias e horas trabalhadas, incluindo turnos que atravessam a meia-noite.
- Alertas visuais para sequências de noites e intervalos curtos entre turnos.
- Repetição de semanas e importação de padrões.
- Desfazer última alteração de escala.
- Suporte a vários turnos no mesmo dia.
- Notas por dia e gestão de trocas de turno pendentes/confirmadas.
- Partilha da escala mensal em imagem PNG e PDF.
- Backup e restauro JSON através do seletor de ficheiros Android.
- Widget Android Hoje/Amanhã com acesso rápido à app.
- Atalho “Organizar depois do turno”.

## 0.3.0 — 2026-08-21

- Página inicial dinâmica antes dos menus.
- Calendário mensal completo para a escala.
- Tipos de turno personalizados persistentes com código, horário, categoria e cor.
- Aplicação rápida de turnos a partir do calendário.

## 0.2.0 — 2026-08-21

- Agenda, objetivos, hábitos, Health Connect, notificações e motor de planeamento expandido.

## 0.1.0

- Dashboard, tarefas, turnos e primeiro motor “Organiza a minha vida”.

- Revisão visual orgânica: tipografia única, cabeçalhos em cartões, transparência fixa e maior contraste.
- Home: saudação automática por hora, nome sem exemplos/avatar e data completa com ano.
- Plano inteligente: cada dia apresentado em cartão próprio.
- Turnos: resumo mensal por tipologia e avisos com datas em dd/MM.
